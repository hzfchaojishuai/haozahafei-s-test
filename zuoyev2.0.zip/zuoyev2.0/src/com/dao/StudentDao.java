package com.dao;

import com.entity.Student;
import com.entity.ZuoYe;
import com.entity.ZuoYeList;
import com.util.DbUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class StudentDao {

    /**
     * 登录
     * @return
     */
    public Student login(String no, String pwd){
        Student student=null;
        String sql="select * from student where no=? and pwd=?";
        //2 调用方法实现
        Object[] args = {no,pwd};
        List<Map<String,Object>> mapList= DbUtils.query(sql,args);
        if(mapList!=null&&mapList.size()>=1){
            Map<String,Object> map=mapList.get(0);
            student=new Student();
            student.setStuid(Integer.parseInt(map.get("stuid").toString()));
            student.setNo(map.get("no").toString());
            student.setName(map.get("name").toString());
            student.setPwd(map.get("pwd").toString());
            student.setAge(Integer.parseInt(map.get("age").toString()));
            student.setPhone(map.get("phone").toString());
            student.setSex(map.get("sex").toString());
        }
        return student;
    }


    /**
     * 我提交的作业列表
     * @return
     */
    public List<ZuoYeList> list(String no,String type){
        List<ZuoYeList> zuoYeLists=new ArrayList<>();
        String sql="select * from zuoyelist where sno=? and type=?";
        //2 调用方法实现
        Object[] args = {no,type};
        List<Map<String,Object>> mapList= DbUtils.query(sql,args);
        if(mapList!=null&&mapList.size()>=1){
            for (Map<String, Object> map : mapList) {
                ZuoYeList zuoye=new ZuoYeList();
                zuoye.setId(Integer.parseInt(map.get("id").toString()));
                zuoye.setSno(map.get("sno").toString());
                zuoye.setStuname(map.get("stuname").toString());
                zuoye.setZuoye(map.get("zuoye").toString());
                zuoye.setZuoyecontent(map.get("zuoyecontent").toString());
                zuoye.setStatus(Integer.parseInt(map.get("status").toString()));
                zuoye.setFilepath(map.get("filepath")!=null ? map.get("filepath").toString() : "");
                zuoYeLists.add(zuoye);
            }
        }
        return zuoYeLists;
    }

    /**
     * 作业名称
     * @return
     */
    public List<ZuoYe> zuoyeList(){
        List<ZuoYe> zuoYeLists=new ArrayList<>();
        String sql="select * from zuoye ";
        //2 调用方法实现
        List<Map<String,Object>> mapList= DbUtils.query(sql);
        if(mapList!=null&&mapList.size()>=1){
            for (Map<String, Object> map : mapList) {
                ZuoYe zuoye=new ZuoYe();
                zuoye.setId(Integer.parseInt(map.get("id").toString()));
                zuoye.setName(map.get("name").toString());
                zuoYeLists.add(zuoye);
            }
        }
        return zuoYeLists;
    }

    /**
     * 提交作业数据
     * @param zuoYeLists
     * @return
     */
    public int insert(ZuoYeList zuoYeLists) {
        //1 创建 sql 语句
        String sql = "insert into zuoyelist values(?,?,?,?,?,?,?,?)";
        //2 调用方法实现
        int i = (int)(Math.random()*10000+1);
        Object[] args = {i,zuoYeLists.getSno(),zuoYeLists.getStuname(), zuoYeLists.getZuoye(),zuoYeLists.getZuoyecontent(),1,zuoYeLists.getType(),zuoYeLists.getFilepath()};
        int conut=DbUtils.update(sql,args);
        return conut;
    }

    /**
     * 注册成功
     * @param student
     * @return
     */
    public int register(Student student) {
        //1 创建 sql 语句
        String sql = "insert into student values(?,?,?,?,?,?,?)";
        //2 调用方法实现
        int i = (int)(Math.random()*10000+1);
        Object[] args = {i,student.getNo(),student.getName(), student.getPwd(),student.getAge(),student.getPhone(),student.getSex()};
        int conut=DbUtils.update(sql,args);
        return conut;
    }

    /**
     * 查询文件
     * @param fileName
     * @return
     */
    public List<ZuoYeList> zuoyeListId(String fileName) {
        List<ZuoYeList> zuoYeLists=new ArrayList<>();
        String sql="select * from zuoyelist where id=?";
        //2 调用方法实现
        Object[] args = {fileName};
        List<Map<String,Object>> mapList= DbUtils.query(sql,args);
        if(mapList!=null&&mapList.size()>=1){
            for (Map<String, Object> map : mapList) {
                ZuoYeList zuoye=new ZuoYeList();
                zuoye.setId(Integer.parseInt(map.get("id").toString()));
                zuoye.setSno(map.get("sno").toString());
                zuoye.setStuname(map.get("stuname").toString());
                zuoye.setZuoye(map.get("zuoye").toString());
                zuoye.setZuoyecontent(map.get("zuoyecontent").toString());
                zuoye.setStatus(Integer.parseInt(map.get("status").toString()));
                zuoye.setFilepath(map.get("filepath")!=null ? map.get("filepath").toString() : "");
                zuoYeLists.add(zuoye);
            }
        }
        return zuoYeLists;
    }
}

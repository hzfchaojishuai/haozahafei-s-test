package com.servlet;

import com.dao.*;
import com.entity.Student;
import com.entity.ZuoYe;
import com.entity.ZuoYeList;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import java.awt.print.Book;
import java.io.*;
import java.util.List;
import java.util.Map;

/**
 * 控制层入口
 */
public class StudentServlet extends javax.servlet.http.HttpServlet {

    private static final long serialVersionUID = 1L;

    // 上传文件存储目录
    private static final String UPLOAD_DIRECTORY = "upload";

    // 上传配置
    private static final int MEMORY_THRESHOLD   = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE      = 1024 * 1024 * 40; // 40MB
    private static final int MAX_REQUEST_SIZE   = 1024 * 1024 * 50; // 50MB
    /**
     * 控制入口
     * @param req
     * @param resp
     * @throws javax.servlet.ServletException
     * @throws IOException
     */
    protected void doPost(javax.servlet.http.HttpServletRequest req, javax.servlet.http.HttpServletResponse resp) throws javax.servlet.ServletException, IOException {

        System.out.println("-----------StudentServlet-------------");
        /*
         * 1.调用模型层的方法来处理客户端的请求，处理结束后将不同的视图资源响应于客户端
         * */
        HttpSession httpSession=req.getSession();
        StudentDao studentDao=new StudentDao();
        String method = req.getParameter("method");
        if(method==null||method.equals("")){
            method="insert";
        }
        if(method.equals("login")){//登录
            String no=req.getParameter("no");
            String pwd=req.getParameter("pwd");
            Student stulist = studentDao.login(no,pwd);
            if(stulist!=null){//登录成功
                httpSession.setAttribute("stulist",stulist);
                resp.getWriter().write("success");
            }else{
                resp.getWriter().write("error");
            }
        }else if(method.equals("list")){//我的作业列表
            Student student=(Student)httpSession.getAttribute("stulist");
            String type=req.getParameter("type");
            List<ZuoYeList> zuoYeLists=studentDao.list(student.getNo(),type);
            if(type.equals("1")){
                req.setAttribute("zuoYeListsname","开题");
            }else if(type.equals("2")){
                req.setAttribute("zuoYeListsname","中期");
            }else{
                req.setAttribute("zuoYeListsname","评阅书");
            }
            req.setAttribute("zuoYeLists",zuoYeLists);
            req.getRequestDispatcher("stu_list.jsp").forward(req,resp);
        }else if(method.equals("add")){//新增作业
            List<ZuoYe> zuoYeLists=studentDao.zuoyeList();
            req.setAttribute("zuoye",zuoYeLists);
            req.getRequestDispatcher("addstu.jsp").forward(req,resp);
        }else if(method.equals("insert")){//提交作业
            //文件上传
            // 检测是否为多媒体上传
            if (!ServletFileUpload.isMultipartContent(req)) {
                // 如果不是则停止
                PrintWriter writer = resp.getWriter();
                writer.println("Error: 表单必须包含 enctype=multipart/form-data");
                writer.flush();
                return;
            }
            // 配置上传参数
            DiskFileItemFactory factory = new DiskFileItemFactory();
            // 设置内存临界值 - 超过后将产生临时文件并存储于临时目录中
            factory.setSizeThreshold(MEMORY_THRESHOLD);
            // 设置临时存储目录
            factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

            ServletFileUpload upload = new ServletFileUpload(factory);

            // 设置最大文件上传值
            upload.setFileSizeMax(MAX_FILE_SIZE);

            // 设置最大请求值 (包含文件和表单数据)
            upload.setSizeMax(MAX_REQUEST_SIZE);

            // 中文处理
            upload.setHeaderEncoding("UTF-8");

            // 构造临时路径来存储上传的文件
            // 这个路径相对当前应用的目录
            String uploadPath = req.getServletContext().getRealPath("./") + File.separator + UPLOAD_DIRECTORY;


            // 如果目录不存在则创建
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }

            try {
                // 解析请求的内容提取文件数据
                @SuppressWarnings("unchecked")
                List<FileItem> formItems = upload.parseRequest(req);

                if (formItems != null && formItems.size() > 0) {
                    ZuoYeList zuoYeLists=new ZuoYeList();
                    Student student=(Student)httpSession.getAttribute("stulist");
                    zuoYeLists.setSno(student.getNo());
                    zuoYeLists.setStuname(student.getName());
                    // 迭代表单数据
                    for (FileItem item : formItems) {
                        // 处理不在表单中的字段
                        if (!item.isFormField()) {
                            String fileName = new File(item.getName()).getName();
                            String filePath = uploadPath + File.separator + fileName;
                            File storeFile = new File(filePath);
                            // 保存文件到硬盘
                            item.write(storeFile);
                            zuoYeLists.setFilepath(filePath);
                            int count=studentDao.insert(zuoYeLists);
                            if(count==1){
                                resp.getWriter().write("success");
                            }else{
                                resp.getWriter().write("error");
                            }
                            resp.sendRedirect("/StudentServlet?method=list&type="+zuoYeLists.getType());
                        }else{
                            String fieldName = item.getFieldName();
                            if (fieldName.equals("zuoye")) {
                                zuoYeLists.setZuoye(item.getString("utf-8"));
                            } else if (fieldName.equals("type")) {
                                zuoYeLists.setType(Integer.parseInt(item.getString("utf-8")));
                            }else if(fieldName.equals("zuoyecontent")){
                                zuoYeLists.setZuoyecontent(item.getString("utf-8"));
                            }
                        }
                    }
                }
            } catch (Exception ex) {
                req.setAttribute("message",
                        "错误信息: " + ex.getMessage());
            }


        }else if(method.equals("register")){//提交作业
            String no=req.getParameter("no");
            String name=req.getParameter("name");
            String age=req.getParameter("age");
            String phone=req.getParameter("phone");
            String sex=req.getParameter("sex");
            String pwd=req.getParameter("pwd");
            Student student=new Student();
            student.setNo(no);
            student.setName(name);
            student.setAge(Integer.parseInt(age));
            student.setPhone(phone);
            student.setSex(sex);
            student.setPwd(pwd);
            int count=studentDao.register(student);
            if(count==1){
                resp.getWriter().write("success");
            }else{
                resp.getWriter().write("error");
            }
        }else if(method.equals("down")){//下载
            req.setCharacterEncoding("UTF-8");
            resp.setContentType("text/html;charset=UTF-8");

            String fileName = req.getParameter("filename");
            List<ZuoYeList> zuoYeLists=studentDao.zuoyeListId(fileName);
            //获取文件的mime类型  (类似text/html...)
            String mime =zuoYeLists.get(0).getFilepath();
            if(mime==null||"".equals(mime)){
                resp.getWriter().write("文件不存在");
                return;
            }
            String type="";
            String substring="";
            int indexOf = mime.lastIndexOf(".");
            if (indexOf > 0) {
                substring= mime.substring(indexOf);
                type=fileMIMEType(substring);
                System.out.println("substring===================="+substring);

            }
//浏览器用下载的方式打开文件
            resp.setHeader("ContentType", type);
            resp.setHeader("Content-Disposition", "attachment; fileName=file"+substring);

            File file = new File(mime); //根据路径创建file对象
            FileInputStream in =new FileInputStream(file); //把file对象装载成输入流 in
            OutputStream out = resp.getOutputStream(); //得到向浏览器输出流 out
            byte[] b = new byte[1024]; //缓冲区
            int len = 0;

            while ((len = in.read(b)) != -1) { //循环读取
                out.write(b, 0, len);
            }

            in .close();
            out.close();
        }
    }

    public String fileMIMEType(String substring){
        if (substring.equals(".GIF") || substring.equals(".gif") || substring.toUpperCase().equals(".GIF")) {
            return "image/gif";

        } else if(substring.equals(".BMP") || substring.equals(".bmp") || substring.toUpperCase().equals(".BMP")) {
            return "image/bmp";

        } else if (substring.equals(".JPEG") || substring.equals(".jpeg") || substring.equals(".JPG")
                || substring.equals(".jpg") || substring.equals(".PNG")
                || substring.equals(".png") || substring.toUpperCase().equals(".JPEG")
                || substring.toUpperCase().equals(".JPG") || substring.toUpperCase().equals(".PNG")) {
            return "image/jpeg";

        } else if (substring.equals(".HTML") || substring.equals(".html")) {
            return "text/html";

        } else if (substring.equals(".TXT") || substring.equals(".txt") || substring.toUpperCase().equals(".TXT")){
            return "text/plain";

        } else if (substring.equals(".VSD") || substring.equals(".vsd") || substring.toUpperCase().equals(".VSD")){
            return "application/vnd.visio";

        } else if (substring.equals(".PPTX") || substring.equals(".pptx") || substring.equals(".PPT")
                || substring.equals(".ppt") || substring.toUpperCase().equals(".PPTX")
                || substring.toUpperCase().equals(".PPT")){
            return "application/vnd.ms-powerpoint";

        } else if(substring.equals(".DOCX") || substring.equals(".docx") || substring.equals(".DOC")
                || substring.equals(".doc") || substring.toUpperCase().equals(".DOCX")
                || substring.toUpperCase().equals(".DOC")){
            return "application/msword";

        } else if(substring.equals(".XML") || substring.equals(".xml") || substring.toUpperCase().equals(".XML")){
            return "text/xml";

        } else if(substring.equals(".pdf") || substring.equals(".PDF") || substring.toUpperCase().equals(".PDF")){
            return "application/pdf";

        } else {
            return null;
        }
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doPost(request, response);
    }
}

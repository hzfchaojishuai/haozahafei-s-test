package com.servlet;

import com.dao.StudentDao;
import com.dao.TeacherDao;
import com.entity.Student;
import com.entity.Teacher;
import com.entity.ZuoYe;
import com.entity.ZuoYeList;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * 控制层入口
 */
public class TeacherServlet extends javax.servlet.http.HttpServlet {
    /**
     * 控制入口
     * @param req
     * @param resp
     * @throws javax.servlet.ServletException
     * @throws IOException
     */
    protected void doPost(javax.servlet.http.HttpServletRequest req, javax.servlet.http.HttpServletResponse resp) throws javax.servlet.ServletException, IOException {

        System.out.println("-----------TeacherServlet-------------");
        /*
         * 1.调用模型层的方法来处理客户端的请求，处理结束后将不同的视图资源响应于客户端
         * */
        HttpSession httpSession=req.getSession();
        TeacherDao teacherDao=new TeacherDao();
        String method = req.getParameter("method");
        if(method.equals("login")){//登录
            String no=req.getParameter("no");
            String pwd=req.getParameter("pwd");
            Teacher stulist = teacherDao.login(no,pwd);
            if(stulist!=null){//登录成功
                httpSession.setAttribute("teacherlist",stulist);
                resp.getWriter().write("success");
            }else{
                resp.getWriter().write("error");
            }
        }else if(method.equals("list")){//我的作业列表
            String type=req.getParameter("type");
            List<ZuoYeList> zuoYeLists=teacherDao.list(type);
            if(type.equals("1")){
                req.setAttribute("zuoYeListsname","开题");
            }else if(type.equals("2")){
                req.setAttribute("zuoYeListsname","中期");
            }else{
                req.setAttribute("zuoYeListsname","评阅书");
            }
            req.setAttribute("zuoYeLists",zuoYeLists);
            req.getRequestDispatcher("teacher_list.jsp").forward(req,resp);
        }else if(method.equals("shenhe")){//审核作业
            String id=req.getParameter("id");
            int count=teacherDao.update(id);
            resp.sendRedirect("/TeacherServlet?method=list&type=1");
        }else if(method.equals("stulist")){//提交作业
            List<Student> zuoYeLists=teacherDao.stulist();
            req.setAttribute("studentlist",zuoYeLists);
            req.getRequestDispatcher("studentlist.jsp").forward(req,resp);
        }else if(method.equals("register")){//提交作业
            String no=req.getParameter("no");
            String name=req.getParameter("name");
            String age=req.getParameter("age");
            String phone=req.getParameter("phone");
            String sex=req.getParameter("sex");
            String pwd=req.getParameter("pwd");
            Teacher student=new Teacher();
            student.setNo(no);
            student.setName(name);
            student.setAge(Integer.parseInt(age));
            student.setPhone(phone);
            student.setSex(sex);
            student.setPwd(pwd);
            int count=teacherDao.register(student);
            if(count==1){
                resp.getWriter().write("success");
            }else{
                resp.getWriter().write("error");
            }
        }
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doPost(request, response);
    }
}

package com.entity;

public class ZuoYe {

    /**
     * id
     */
    private int id;
    /**
     * 作业名称
     */
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

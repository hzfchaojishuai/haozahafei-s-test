package com.entity;

public class ZuoYeList {

    /**
     * id
     */
    private int id;
    /**
     * 学号
     */
    private String sno;
    /**
     * 姓名
     */
    private String stuname;
    /**
     * 作业名称
     */
    private String zuoye;
    /**
     * 作业内容
     */
    private String zuoyecontent;

    /**
     * 作业审核1.待审核，2.老师已审核
     */
    private Integer status;

    /**
     * 1.开题，2.中期
     */
    private Integer type;

    /**
     * 文件路径
     */
    private String filepath;

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public String getStuname() {
        return stuname;
    }

    public void setStuname(String stuname) {
        this.stuname = stuname;
    }

    public String getZuoye() {
        return zuoye;
    }

    public void setZuoye(String zuoye) {
        this.zuoye = zuoye;
    }

    public String getZuoyecontent() {
        return zuoyecontent;
    }

    public void setZuoyecontent(String zuoyecontent) {
        this.zuoyecontent = zuoyecontent;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}

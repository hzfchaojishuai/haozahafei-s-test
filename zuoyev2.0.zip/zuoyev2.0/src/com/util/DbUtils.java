package com.util;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据库工具类
 */
public class DbUtils {
    private static final String JDBC_DRIVER="com.mysql.cj.jdbc.Driver";
    private static final String JDBC_URL="jdbc:mysql://localhost:3306/zuoye?allowMultiQueries=true&useUnicode=true&useSSL=true&characterEncoding=utf-8&serverTimezone=GMT%2B8";
    private static final String JDBC_USERNAME="root";
    private static final String JDBC_PASSWORD="7618625Fei";
    private static Connection conn=null;
    //1、加载驱动用静态块来实现，自动调用
    static{
        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("驱动加载失败");
        }
    }
    //2、打开连接
    public static Connection openConnection(){
        try {
            if(conn==null||conn.isClosed()){
                conn= DriverManager.getConnection(JDBC_URL,JDBC_USERNAME,JDBC_PASSWORD);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    /**
     * 执行DML操作
     * @param sql
     * @param params
     * @return
     */
    public  static int update(String sql,Object...params){//Object...params为可变参数
        Connection conn=openConnection();//打开连接
        int row=0;
        PreparedStatement pst=null;
        try {
            pst=conn.prepareStatement(sql);
            if(params!=null&&params.length>0){
                for(int i=0;i<params.length;i++){
                    pst.setObject(i+1,params[i]);
                }
                row=pst.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("执行DML异常",e);
        }finally{
            if(pst!=null){
                try {
                    pst.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return row;
    }

    /**
     * 执行查询操作
     * @param sql
     * @param params
     * @return
     */
    public  static List<Map<String,Object>> query(String sql, Object...params){
        Connection conn=openConnection();//打开连接
        ResultSet rs=null;
        PreparedStatement pst=null;
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        try {
            pst=conn.prepareStatement(sql);
            if(params!=null&&params.length>0){
                for(int i=0;i<params.length;i++){
                    pst.setObject(i+1,params[i]);
                } }
            rs=pst.executeQuery();//查询之后返回一个结果集
            //解析结果集
            //首先获取rs里面的元数据
            ResultSetMetaData rsmd=  rs.getMetaData();
            int count=rsmd.getColumnCount();//得到列的总数
            while(rs.next()){
                Map<String,Object> row=new HashMap<String,Object>();
                //具体解析
                for(int i=0;i<count;i++){
                    String columnLabel=rsmd.getColumnLabel(i+1);//得到列的名字
                    row.put(columnLabel,rs.getObject(columnLabel));
                }
                list.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("执行查询异常",e);
        }finally{
            if(rs!=null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(pst!=null){
                try {
                    pst.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return list;
    }

    /**
     * 关闭连接
     */
    public  static void close(){
        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            conn=null;
        }
    }
}

